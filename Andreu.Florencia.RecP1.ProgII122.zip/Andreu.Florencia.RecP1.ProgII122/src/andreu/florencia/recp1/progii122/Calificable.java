
package andreu.florencia.recp1.progii122;

public interface Calificable {
    void calificar(int puntaje);
}
