
package andreu.florencia.recp1.progii122;

class EspectaculoDuplicadoExcepcion extends Exception {
    public EspectaculoDuplicadoExcepcion(String mensaje){
        super(mensaje);
    }
}
