
package andreu.florencia.recp1.progii122;

public enum Clasificacion {
    ATP, MAYOR13, MAYOR18
}
