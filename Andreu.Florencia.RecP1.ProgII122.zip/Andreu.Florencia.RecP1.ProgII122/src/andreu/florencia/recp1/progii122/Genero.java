
package andreu.florencia.recp1.progii122;


public enum Genero {
    POP, ROCK, JAZZ
}
