
package andreu.florencia.recp1.progii122;

public interface Transmitible {
    void transmitir();
}
